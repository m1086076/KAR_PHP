<?php

class Bank{

    public $accountHolderName;
    public $accountNumber;
    public $accountType;
    public $accountBalance = 0;
    public $investmentAccountType;


    /** 
     * accountHolderName will be string 
     */
    public function setAccountHolderName($accountHolderName)
    {
        $this->accountHolderName = $accountHolderName;
    }

    public function getAccountHolderName()
    {
        return $this->accountHolderName;
    }

    /** 
     * accountNumber will be int
     */
    public function setAccountNumber($accountNumber)
    {
        $this->accountNumber = $accountNumber;
    }

    public function getAccountNumber()
    {
        return $this->accountNumber;
    }

    /** 
     * accountType will be string
     */
    public function setAccountType($accountType)
    {
        $this->accountType = $accountType;
    }

    public function getAccountType()
    {
        return $this->accountType;
    }

    /** 
     * investmentAccountType will be string
     */
    public function setInvestmentAccountType($investmentAccountType)
    {
        $this->investmentAccountType = $investmentAccountType;
    }

    public function getInvestmentAccountType()
    {
        return $this->investmentAccountType;
    }

    /** 
     * accountBalance will be float
     */
    public function setAccountBalance($accountBalance)
    {
        $this->accountBalance = $accountBalance;
    }

    public function getAccountBalance()
    {
        return $this->accountBalance;
    }

}