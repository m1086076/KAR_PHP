<?php

define("BANK", "HDFC Bank");
define("ACOUNT_TYPE_REV","REVIEWING");
define("ACOUNT_TYPE_INVT","INVESTMENT");
define("ACOUNT_TYPE_INDV","INDIVISUAL");
define("ACOUNT_TYPE_CORP","CORPORATE");
define("WITHDRAWLIMIT","500"); //500$ 


